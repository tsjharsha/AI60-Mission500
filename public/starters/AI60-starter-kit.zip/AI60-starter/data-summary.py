import csv
from pathlib import Path
rows = list(csv.DictReader(Path(__file__).with_name('signups.csv').open()))
values = [float(row['signups']) for row in rows]
change = (values[-1] - values[0]) / values[0] * 100 if values[0] else None
print({'first': values[0], 'last': values[-1], 'percentage_change': change,
       'largest_weekly_increase': max(b-a for a,b in zip(values, values[1:]))})
print('Explain only these computed values. These rows do not establish a cause.')
