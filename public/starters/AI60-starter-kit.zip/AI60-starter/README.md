# AI60 starter kit

A guided learning scaffold, not a production AI system.

1. Install Node.js 20 or newer.
2. Run `npm install` in this folder.
3. Run `npm start`, then open http://127.0.0.1:8080.
4. Choose a project. The default mode displays PREPARED EXAMPLES only.
5. For a real model response, set GEMINI_API_KEY and GEMINI_MODEL on the server, then start again. Check provider access and cost limits first. The API key stays on the server.
6. Test three examples. Save one failure and write a README explaining the limitation.

SQL: never run generated queries against production data.
Data: verify numeric claims against computed statistics; do not claim causality.
Feedback: retain comment IDs and review suggested themes.

Plan: 10 minutes setup, 20 build, 15 check, 15 demo.
The workshop date and joining link have not been supplied.
