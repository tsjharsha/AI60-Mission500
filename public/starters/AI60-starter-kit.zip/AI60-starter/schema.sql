CREATE TABLE students(name TEXT, branch TEXT);
INSERT INTO students VALUES ('Asha','CSE'),('Ravi','ECE');
